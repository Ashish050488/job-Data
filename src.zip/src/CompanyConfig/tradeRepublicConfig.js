import { StripHtml, COMMON_KEYWORDS } from "../utils.js"
import { createLocationPreFilter } from "../core/Locationprefilters.js";

export const tradeRepublicConfig =  {
    siteName: "Trade Republic",
    apiUrl: "https://api.traderepublic.com/api/v1/career/jobs?content=true",
    method: "GET",
    filterKeywords: [...COMMON_KEYWORDS],
    getBody: () => null,
    getJobs: (data) => data?.jobs || [],
    getTotal: (data) => data?.jobs?.length || 0,
    
    // ✅ USE UNIVERSAL PRE-FILTER
    // Tell it which field contains the location
    preFilter: createLocationPreFilter({ 
        locationFields: ['location.name', 'Location'] 
    }),
    
    mapper: (job) => ({
      JobTitle: job.title || "",
      JobID: job.id ? String(job.id) : "",
      Location: job.location?.name || "N/A",
      PostingDate: job.updated_at || "",
      Department: job.departments?.[0]?.name || "N/A",
      Description: StripHtml(job.content || ""),
      ApplicationURL: job.absolute_url || "",
      ContractType: "N/A",
      ExperienceLevel: "N/A"
    })
}